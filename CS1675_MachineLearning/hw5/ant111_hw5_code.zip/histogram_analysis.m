%% Problem 2(f) - plots histogram with 20 bins of vector X of atrribute values
function [] = histogram_analysis(x)

hist(x,20);
