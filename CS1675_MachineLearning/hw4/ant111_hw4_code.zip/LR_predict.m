function y = LR_predict(X,w)
%Solves for y given data X and weights w
    y = X*w;
end

