function w = LR_solve(X, y)
%Returns weights for linear regression
    w = X\y;
end

